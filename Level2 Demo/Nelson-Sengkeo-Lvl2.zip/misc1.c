/************* lvl1misc.c file **************/

int stat_file(char *pathname)
{

    //get inode of filename into memory
    int ino = getino(pathname);
    MINODE *mip = iget(dev, ino);
    INODE *ip = &mip->INODE;
    
    //copy dev and ino into stat struct
    myst.st_dev = dev;
    //printf("device # is %d\n", myst.st_dev);
    myst.st_ino = ino;
    //printf("ino number is %d\n", myst.st_ino);

    //copy mip->inode fields into stat struct
    myst.st_atime = ip->i_atime;
    myst.st_ctime = ip->i_ctime;
    myst.st_mode = ip->i_mode;
    myst.st_mtime = ip->i_mtime;
    myst.st_nlink = ip->i_links_count;
    myst.st_size = ip->i_size;
    myst.st_uid = ip->i_uid;

    iput(mip);//still call iput to lower use count even though we didnt change anything
}

int chmod_file(char *pathname, int mode)
{
    //get INODE of pathname into memory
    int ino = getino(pathname);
    MINODE *mip = iget(dev, ino);

    if (mip->INODE.i_mode == mode)
    {
        printf("Can't change to same mode\n");
        return 0;
    }
    mip->INODE.i_mode = mode;

    mip->dirty = 1;
    iput(mip);
}

int utime_file(char *pathname)
{
    int ino = getino(pathname);
    if (ino == 0)
    {
        printf("File %s doesn't exist\n", pathname);
    }

    MINODE *mip = iget(dev, ino);
    mip->INODE.i_atime = time(0L);

    mip->dirty = 1;
    iput(mip);
}